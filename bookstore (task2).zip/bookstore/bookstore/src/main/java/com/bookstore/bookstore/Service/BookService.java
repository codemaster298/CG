package com.bookstore.bookstore.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookstore.bookstore.Model.Book;
import com.bookstore.bookstore.Repository.BookRepository;

@Service
public class BookService {

	private final BookRepository bookRepository;

    @Autowired
    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }
    
	public Book createBook(Book book) {
		// TODO Auto-generated method stub
		return bookRepository.save(book);
	}

	public List<Book> getAllBooks() {
		// TODO Auto-generated method stub
		return bookRepository.findAll();
	}

	public Book getBookById(Long id) {
		// TODO Auto-generated method stub
		Optional<Book> optionalBook = bookRepository.findById(id);
        return optionalBook.orElse(null);
        }

	public void deleteBook(Long id) {
		// TODO Auto-generated method stub
		bookRepository.deleteById(id);

	}

	public Book updateBook(Long id, Book updatedBook) {
		// TODO Auto-generated method stub
		 Optional<Book> optionalExistingBook = bookRepository.findById(id);
	        if (optionalExistingBook.isPresent()) {
	            Book existingBook = optionalExistingBook.get();
	            existingBook.setTitle(updatedBook.getTitle());
	            existingBook.setAuthor(updatedBook.getAuthor());
	            existingBook.setIsbn(updatedBook.getIsbn());
	            existingBook.setPublicationYear(updatedBook.getPublicationYear());
	            // Update other fields as needed
	            return bookRepository.save(existingBook);
	        }
	        return null; // Book with given ID not found
	    }
	}

